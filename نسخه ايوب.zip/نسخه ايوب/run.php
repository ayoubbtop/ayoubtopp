<?php
date_default_timezone_set("Asia/Baghdad");
error_reporting(0);
if (!file_exists("ID")) {
$g = readline("⌁ ID Admin : ");
file_put_contents("ID", $g);
}

if (!file_exists("token")) {
$g = readline("⌁ Token Bot : ");
file_put_contents("token", $g);
}


echo "Done Run Bot\n\n\n\n";