<?php
date_default_timezone_set("Asia/Baghdad");

function bot($method,$datas=[]){
    $datas = http_build_query($datas);
    $url = "https://api.telegram.org/bot".file_get_contents('token')."/".$method."?$datas";
    $get = file_get_contents($url);
    return json_decode($get);
}

$user = file_get_contents("username");

while (true) {
    usleep(500000);
    $get = @file_get_contents('https://t.me/' . $user);
    if (preg_match('/(<div class="tgme_page_extra">)/', $get)) {
bot('sendMessage', ['chat_id' => file_get_contents("ID"), 'text' => "- Un Flood => @$user 🚫",]);

        shell_exec("screen -S flood -X kill");
shell_exec("screen -S tik -X kill");
        
        exit;
    } else {

    }
}
