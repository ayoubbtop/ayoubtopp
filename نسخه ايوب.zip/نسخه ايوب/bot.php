<?php 
  $sudo = file_get_contents("ID");
  $token = file_get_contents("token");
  define('token',$token);define('sudo',$token);
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".token."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res,true);}}
function states($num){
  $st = "";
  $x = shell_exec("pm2 show $num");
if(strstr($x,"online")){
  $st = ": Running";
 }else{
  $st = ": Stopping";
}
 return $st;
}

$lastupdid = 1; 
while(true){ 
 $upd = bot("getUpdates", ["offset" => $lastupdid]); 
 if(isset($upd['result'][0])){ 
  $text = $upd['result'][0]['message']['text']; 
  $chat_id = $upd['result'][0]['message']['chat']['id']; 
$from_id = $upd['result'][0]['message']['from']['id']; 
$message = $upd['result'][0]['message']; 
$name = $message['from']['first_name'];
$nn = bot('getme', ['bot']) ["result"]["username"];
$info = json_decode(file_get_contents('info.json'),true);
$value = "";
$admin = $sudo;
if ($chat_id == $admin) {
if ($text == "/start") {
bot('sendmessage',['chat_id'=>$chat_id, 'text'=>"
- 𝐇𝐢 𝐃𝐚𝐞𝐫 $name 🌪,

- 𝐖𝐞𝐥𝐜𝐨𝐦𝐞 𝐓𝐨 𝐁𝐨𝐭 𝐅𝐥𝐨𝐨𝐝 𝐔𝐬𝐞𝐫𝐬 ,
",
'reply_markup' => json_encode(['resize_keyboard' => true, 'keyboard' => [
[["text" =>"اضف يوزر"]],
[["text" =>"تشغيل"],["text" =>"ايقاف"]],
[["text" =>"عدد حساباتك"],["text" =>"استدعاء سيشنات"]],

[["text" =>"فحص سيشنات"]],
],])]);
file_put_contents("step","");}


$ex = explode('/add ',$text);
if($ex[1] != null){
if($ex[0] == null){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"- Done Add Account ✅
",
]);
$arr = json_decode(file_get_contents('session.json'),true);
$arr['session'][] = $ex[1];
file_put_contents("session.json",json_encode($arr,448));
}
}

if($text == "استدعاء سيشنات"){
	 $accounts = json_decode(file_get_contents('session.json'),true);
$count = count($accounts['session']);
bot('SendDocument',[
'chat_id'=>$chat_id,
'document'=>new CURLFile("session.json"),
'caption'=>"This All Session $count 🛎️",
]);
}

if($text == "عدد حساباتك"){
 $accounts = json_decode(file_get_contents('session.json'),true);
$count = count($accounts['session']);
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"Count Account : [ $count ] ❗
",
]);
}
if($text == "اضف يوزر"){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"ارسل اليوزر ☑️
",
]);
file_put_contents('username','ok');
}
$Ex = str_replace("@","",$text);
if(file_get_contents("username") == "ok"){
if($text and $text !="اضف يوزر"){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"تم اضافته $text ,
",
]);
file_put_contents('username',$Ex);
}
}

if($text == "فحص سيشنات"){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"Session Scan is Running 🔃
",
]);
shell_exec("screen -S filter -X kill");
shell_exec("screen -dmS filter python3 filter.py");
}
if($text == "sʟᴇᴇᴘ"){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"Send Sleep Time ⏳
",
]);
file_put_contents('sleeps','ok');
}
if(file_get_contents("sleeps") == "ok"){
if($message and $text !="sʟᴇᴇᴘ"){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"Done Set Sleep Time $text 🕰️
",
]);
file_put_contents('sleeps',$text);
}
}
if($text == "ايقاف"){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"- Done Stop ",]);
shell_exec("screen -S flood -X kill");
}
if($text == "⤷ Add Session"){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"Sand Session Ex : /add + session pyrogram ✅",]);}

if($text == "تشغيل"){
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"ʀᴜɴ « ғʟᴏᴏᴅ »
",]);
shell_exec("screen -S tik -X kill");
shell_exec("screen -dmS tik php tik.php");
shell_exec("screen -S flood -X kill");
shell_exec("screen -dmS flood python3 flood.py");
}
}
$lastupdid = $upd['result'][0]['update_id'] + 1; 
} 
}